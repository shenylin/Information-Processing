"""Demonstrate importing and using decisions_55_my_utility_functions module"""

from decisions_55_my_utility_functions import meters_to_inches


def main():
    print(f'\n20 meters is equal to {meters_to_inches(20.0)} inches.')


main()
